import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'get_table_resto_event.dart';
part 'get_table_resto_state.dart';

class GetTableRestoBloc extends Bloc<GetTableRestoEvent, GetTableRestoState> {
  GetTableRestoBloc() : super(GetTableRestoInitial()) {
    on<GetTableRestoEvent>((event, emit) {
      // TODO: implement event handler
    });
  }
}
