part of 'get_table_resto_bloc.dart';

@immutable
sealed class GetTableRestoState {}

final class GetTableRestoInitial extends GetTableRestoState {}
