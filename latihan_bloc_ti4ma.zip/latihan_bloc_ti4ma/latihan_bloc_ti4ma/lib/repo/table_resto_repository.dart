import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:latihan_bloc_ti4ma/core/api_client.dart';
import 'package:latihan_bloc_ti4ma/models/table_restos_model.dart';

class TableRestoRepository extends ApiClient{
  Future<List<TableRestoModel>> getTableRestos() async{
    try{
      var response = await dio.get('table-resto-list');
      debugPrint('Table Resto GET ALL : ${response.data}');
      List list = response.data;
      List<TableRestoModel> listTableResto =
          list.map((element) => TableRestoModel.fromJson(element)).toList();
      return listTableResto;

    } on DioException catch(e){
      throw Exception(e);
      //debugPrint(e.toString());
    }
  }
}