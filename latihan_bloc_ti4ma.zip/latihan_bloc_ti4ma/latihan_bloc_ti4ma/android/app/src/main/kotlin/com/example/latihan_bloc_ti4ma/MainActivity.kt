package com.example.latihan_bloc_ti4ma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
